# Lead

A Linkyum Ethernet Driver



# Driver Code

Linux driver: linux/linkyum.c

Uboot driver: uboot/linkyum.c



# User Guide

User guide: doc/Linkyum PHY Driver User Guide.doc

User guilde for bist: doc/Linkyum PHY Bist User Guide.md 



# Useful Tools

Mdio read/write tool: tools/mdiotool.c

Phy test script: tools/PhySAT.sh